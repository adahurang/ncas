'use strict';

/**
 * @ngdoc function
 * @name certGeneratorWebApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the certGeneratorWebApp
 */
angular.module('certGeneratorWebApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
